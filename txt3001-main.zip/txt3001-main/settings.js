const settings = {
	"MongoDB": "mongodb+srv://croesusbey:croesusbey123@cluster0.u5ocz.mongodb.net/txtmain?retryWrites=true&w=majority",
    "commandChannel": ["bot-commands","entrance"],

    "taglıAlım": false,
    "chatMesajı": "-member-, Aramıza hoş geldiniz! Rol seçim odalarından rolleriniz almayı unutmayın iyi eğlenceler.",

    "YETKI_VER_LOG": "943302322774220883",
    "CEZA_PUAN_KANAL": "944686135161012255",
    "CEZA_PUAN_SYSTEM": true,

    "MODERASYON": "OTQ0NjgwMDU4MzkwNDY2NTYx.YhFH3Q.dJMk9cYrsPEbaeQmys_A_a-a2SU", // mod botu
    "EXECUTIVE": "OTQ0Njc5MTg1ODc4NzQ5MjY0.YhFHDQ.7unKFOnD5qn-8yAWRM1TtakjIR0", // yönetim
    "STATS": "OTQ0Njc5Njc0MTU4NjY5ODMz.YhFHgQ.DsI1CCQDulU9z2aUeJnuotor-vg", // stat
    "LOG":"OTQ0NjgwNjAzNTM2NzI4MTE0.YhFIXw.E5Gs58tRqWewSlmdhsJZkAhag2E",
    
    "prefix": [".","!"],
    "botSesID": "944631801756926023",
    "sunucuId": "941026762706530354",
    "sahip": [
"853427901402710036",
"860119403978817546",
    "207699719768506370"],
    "footer": "Shadox 🖤 SadeceYigit",
    "readyFooter": ["Shadox 🖤 SadeceYigit"]
}

module.exports = settings;
