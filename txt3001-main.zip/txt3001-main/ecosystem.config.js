
const Sunucu_1 = "Shawn";
module.exports = {
    apps: [
        {
            name: `${Sunucu_1}-Executive`,
            script: "./Executive/main.js",
            watch: false
        }, {
            name: `${Sunucu_1}-Moderation`,
            script: "./Moderasyon/main.js",
            watch: false
        },
        {
            name: `${Sunucu_1}-Moderation`,
            script: "./Stats/main.js",
            watch: false
        },
        {
            name: `${Sunucu_1}-Log`,
            script: "./Log/main.js",
            watch: false
        },
    ]
};
