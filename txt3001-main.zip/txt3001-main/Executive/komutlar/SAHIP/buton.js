const disbut = require("discord-buttons");
module.exports.run = async (client, message, args, durum, kanal) => {
    if (!client.ayarlar.sahip.some(x => x == message.author.id)) return;

let etkinlik = new disbut.MessageButton().setStyle('green').setLabel('🎉 Etkinlik Katılımcısı!').setID('etkinlik')
let cekilis = new disbut.MessageButton().setStyle('red').setLabel('🎁 Çekiliş Katılımcısı!').setID('cekilis')
message.channel.send(` Merhaba arkadaşlar, 

**TXT#3001** olarak yapılan etkinlik ve çekilişlerden anında bildirim almanız için yapılan sistemi size sunuyoruz.

Çekiliş katılımcısı alarak **Nitro**, **Spotify**, **Netflix**, **Exxen**, **BluTV** gibi çekilişlere katılıp ödüllerin sahibi olabilirsiniz.

Aşağıda ki seçim menüsünden etkinlik katılımcısı alarak da yapılan konserlerden, etkinliklerden anında haberdar olabilirsiniz.`

, {
    buttons: [cekilis,etkinlik]
})



}
let config = {
    "etkinlik": "944631748849958972",
    "cekilis": "944631747142881371",}
client.on('clickButton', async (button) => {
    if (button.id === 'etkinlik') {
        if (button.clicker.member.roles.cache.get(config.etkinlik)) {
            await button.clicker.member.roles.remove(config.etkinlik);await button.reply.think(true);await button.reply.edit("Rollerin Düzenlendi.")
        } else {
            await button.clicker.member.roles.add(config.etkinlik);await button.reply.think(true);await button.reply.edit("Rollerin Düzenlendi.")
        }
    }
    if (button.id === 'cekilis') {
        if (button.clicker.member.roles.cache.get(config.cekilis)) {
            await button.clicker.member.roles.remove(config.cekilis);await button.reply.think(true);await button.reply.edit("Rollerin Düzenlendi.")
        } else {
            await button.clicker.member.roles.add(config.cekilis);await button.reply.think(true);await button.reply.edit("Rollerin Düzenlendi.")
        }
  
    }
     
  });
exports.conf = {
    aliases: []
}
exports.help = {
    name: 'buton'
}
