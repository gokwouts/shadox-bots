const {
    MessageEmbed,
    Client,
    Message
  } = require("discord.js");
  const Discord = require('discord.js');
  const disbut = require("discord-buttons");
  const client = global.client;
  /**
   * 
   * @param {Client} client 
   * @param {Message} message 
   * @param {Array<String>} args 
   * @param {Boolean} durum 
   * @param {Boolean} kanal 
   * @returns 
   */
  

  
  const renkler = {
    "🍌": "888506052339970078",
    "🍑": "888506055758348388",
    "🍏": "888506053061402654",
    "🍊": "888506054764277770",
    "🍓": "888506050997796864",
    "894525817957265438":"888506053925425174"
  };

  
  const digerler = {
    "💕": "888506114918993951",
    "💔": "888506117108412416",
  }; // iliski 

  exports.run = async (client, message, args, durum, kanal) => {
    if (!message.guild) return;
    let guild = message.guild;
    if (!client.ayarlar.sahip.some(x => x === message.author.id)) return
  
    const oyunPush = [];
    const renkPush = [];
    const digerPush = [];
    const emoji = (name) => client.emojis.cache.find(x => x.name === name);
  

  
    let kaldıroyun = new disbut.MessageMenuOption()
    .setLabel("Kaldır")
    .setEmoji("888881676703399986")
    .setValue("kaldır")
    let oyun = new disbut.MessageMenu();
    oyun.setID("oyun");
    oyun.setPlaceholder(`Oyun rollerini seçmek için tıkla!`);
    oyun.setMaxValues(6);
    oyun.setMinValues(1);
    oyun.addOptions(oyunPush,kaldıroyun);
  
 for (const renk in renkler) {
      const sonuc = renkler[renk];
      let table = new disbut.MessageMenuOption()
        .setLabel(`Rengine sahip olmak için tıkla!`)
        .setEmoji(emoji(renk) ? emoji(renk).id : renk)
        .setValue(sonuc)
      renkPush.push(table);
    };
    let kaldırrenk = new disbut.MessageMenuOption()
    .setLabel("Kaldır")
    .setEmoji("888881676703399986")
    .setValue("kaldır")
    let renk = new disbut.MessageMenu();
    renk.setID("renk");
    renk.setPlaceholder(`Renk rollerini seçmek için tıkla!`);
    renk.setMaxValues(1);
    renk.setMinValues(1);
    renk.addOptions(renkPush,kaldırrenk);
  

  
    for (const diger in digerler) {
      const sonuc = digerler[diger];
      let table = new disbut.MessageMenuOption()
        .setLabel(message.guild.roles.cache.get(sonuc)?.name)
        .setEmoji(emoji(diger) ? emoji(diger).id : diger)
        .setValue(sonuc)
      digerPush.push(table);
    };
    let kaldırdiger = new disbut.MessageMenuOption()
    .setLabel("Kaldır")
    .setEmoji("888881676703399986")
    .setValue("kaldır")
    let diger = new disbut.MessageMenu();
    diger.setID("diger");
    diger.setPlaceholder(`İlişki rolünü seçmek için tıkla!`);
    diger.setMaxValues(1);
    diger.setMinValues(1);
    diger.addOptions(digerPush,kaldırdiger);
  
  
  
    if (args[0] === "renk") {
      message.channel.send(`Aşağıdaki menüye tıklayarak dilediğin rengi seçebilirsin!`, renk);
    }
  
  
    if (args[0] === "iliski") {
      message.channel.send(`İlişki durumunuzu seçmek için aşağıdaki menüyü kullanabilirsiniz!`, diger);
    }
  

  };
  
  client.on("clickMenu", async (menu) => {
    if (menu.id == "renk") {
      await menu.reply.think(true);
      if (!menu.clicker.member.roles.cache.get("852831784596668419")) return await menu.reply.edit("Booster üye olman gerek!");;
      await menu.reply.edit("Rollerin güncellendi!");

      let add = [];
      let remove = [];
      let allRemove = [];
      let roller = renkler;
      for (const rol in roller) {

        let sonuc = roller[rol];  

        allRemove.push(sonuc);
        if (menu.values.includes(sonuc)) {    
          await menu.reply.edit(`Başarılı bir şekilde <@&${sonuc}> rolü üzerinize eklendi!`);

          add.push(sonuc);
        } else {
          remove.push(sonuc);

        };
      };
      if (!menu.values.some(value => value === "allDelete")) {
        if (remove.length > 0) {
          await menu.clicker.member.roles.remove(remove);
        };
        await menu.clicker.member.roles.add(add);
      } else {
        await menu.clicker.member.roles.remove(allRemove);

      };
    };
    if (menu.id == "diger") {
      await menu.reply.think(true);
      await menu.reply.edit("Rollerin güncellendi!");
      let add = [];
      let remove = [];
      let allRemove = [];
      let roller = digerler;
      for (const rol in roller) {
        let sonuc = digerler[rol];
        allRemove.push(sonuc);
        if (menu.values.includes(sonuc)) {
            
          await menu.reply.edit(`Başarılı bir şekilde <@&${sonuc}> rolü üzerinize eklendi!`);
          add.push(sonuc);
        } else {
          remove.push(sonuc);
        };
      };
      if (!menu.values.some(value => value === "allDelete")) {
        if (remove.length > 0) {
          await menu.clicker.member.roles.remove(remove);
         

        };
        await menu.clicker.member.roles.add(add);
      } else {
        await menu.clicker.member.roles.remove(allRemove);
      };
    };

   
  });
  
  exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: ['menü-kurr'],
    permLevel: 4
  };
  
  exports.help = {
    name: 'menü-kur',
    description: "Sunucuda komut denemeye yarar",
    usage: 'eval <kod>',
    kategori: "Bot Yapımcısı"
  };